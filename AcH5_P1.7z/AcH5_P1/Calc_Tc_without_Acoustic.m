% function Calc_Tc(mu)
clear all;
Z = 25;
for i = 1:10
    n = 0;
    filename = strcat('a2F.dos', num2str(i));
%     disp(filename);
    f= fopen(filename, 'r+');
    for t = 1:5
        fgetl(f);
    end
    while ~feof(f)
        tline = fgetl(f);
        if strfind(tline,'lambda')
%             disp(n);
            break
        end
        line = str2num(tline);
        diml = size(line);
        if line(1) ~=0 & diml < 3
            n = n +1;
            elf(n,:) = line;
        end
    end
  W=10000/3.0385;
     for x = 2:length(elf)
        domega = -elf(x-1,1) + elf(x,1);
        intlambda_all(x) = 2*elf(x-1,2)*(exp(-Z/(W*elf(x-1,1))^2))/elf(x-1,1)*domega;
        if elf(x,1) > 0
            intlambda_pos(x) = 2*elf(x-1,2)*(exp(-Z/(W*elf(x-1,1))^2))/elf(x-1,1)*domega;
            intomega2(x) = 2*elf(x-1,2)*(exp(-Z/(W*elf(x-1,1))^2))/elf(x-1,1)*elf(x-1,1)^2*domega;
            intwlog(x) = (2*elf(x-1,2)/elf(x-1,1))*(exp(-Z/(W*elf(x-1,1))^2))*log(elf(x-1,1))*domega;
        else
            intlambda_pos(x) = 0;
        end
    end
    lambda_pos(i) = sum(intlambda_pos);         % Calculate lambda from Eliashberg function for positive freq
    lambda_all(i) = sum(intlambda_all);         % Calculate lambda from Eliashberg function for all freq
    omega2(i) = sqrt(sum(intomega2)/lambda_pos(i));
    omega2_K(i) = omega2(i) *  1.578215400838535e+05;
    wlog(i) = exp(sum(intwlog)/lambda_pos(i));
    wlog_K(i) = wlog(i) *  1.578215400838535e+05;
    
    % Claculation of the coefficients for Allen-Dyen equation
    mu = 0.15;
    L1(i) = 2.46*(1+3.8*mu);
    L2(i) = 1.82*(1+6.3*mu)*(omega2(i)/wlog(i));
    f1(i) = (1+(lambda_pos(i)/L1(i))^(3/2))^(1/3);
    f2(i) = 1 + ((omega2(i)/wlog(i)-1)*lambda_pos(i)^2)/(lambda_pos(i)^2+L2(i)^2);
    
    Tc(i) = f1(i)*f2(i)*wlog_K(i)/1.20 * exp(-(1.04*(1+lambda_pos(i)))/(lambda_pos(i)-mu-0.62*lambda_pos(i)*mu));
    % Claculation of the coefficients for Allen-Dyen equation
    % Claculation of the coefficients for McMillan equation
    Tc_McMillan_pos(i) = wlog_K(i)/1.20 * exp(-(1.04*(1+lambda_pos(i)))/(lambda_pos(i)-mu-0.62*lambda_pos(i)*mu));
    Tc_McMillan_all(i) = wlog_K(i)/1.20 * exp(-(1.04*(1+lambda_all(i)))/(lambda_all(i)-mu-0.62*lambda_all(i)*mu));
    % Claculation of the coefficients for McMillan equation
    if i == 1
        plot(elf(:,1), elf(:,2));
    end
end
% % Fit the lambda(x) using ezyfit program to find the limit of lambda
% x = 1:length(lambda_pos);
% f_pos = ezfit(x,lambda_pos,'a+c*exp(b*x)');
% approx_lambda_pos = f_pos.m(1);
% f_all = ezfit(x,lambda_all,'a+c*exp(b*x)');
% approx_lambda_all = f_all.m(1);
% 
% % Fit the lambda(x) using ezyfit program to find the limit of lambda
% f_tc = ezfit(x,Tc,'a+c*exp(b*x)');
% approx_Tc = f_tc.m(1);

fclose all;
disp('Calculated Tc');
disp(Tc');
disp('Calculated lambda');
disp(lambda_pos');